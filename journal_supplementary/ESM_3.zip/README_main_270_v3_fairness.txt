SHUTTLECOCK PINN V3 FAIRNESS - MAIN 270-RUN PRESET
==================================================

Files required in the same folder:
1. shuttlecock_pinn_diagnostic_v3_fairness.py
2. run_main_270_v3_fairness.py
3. run_main_270_v3_fairness.ipynb   (optional Jupyter interface)
4. run_main_270_macos.command       (optional macOS terminal launcher)

Frozen main design
------------------
Methods: MC-R, LHS-R, ALHS-R
N_f: 50, 100, 200
Seeds: 0..29 (paired)
Total runs: 270
Adam: 5000 epochs, lr=1e-3
Common resampling: every 250 epochs
Physics validation: every 250 epochs, 501 points
L-BFGS: max_iter=300; union of last 4 collocation sets
Endpoint anchors: t=0 and t=T
RK4: evaluation only
SAVE_MODELS=False
RESUME=True

Recommended execution on macOS
------------------------------
Option A: Jupyter
Open run_main_270_v3_fairness.ipynb and run cells in order.

Option B: Terminal
python3 run_main_270_v3_fairness.py

Option C: Terminal with macOS sleep prevention
Double-click/run run_main_270_macos.command
or execute:
  ./run_main_270_macos.command

Resume behavior
---------------
Each N_f budget has its own incremental CSV. If execution stops, rerun the
same preset. Completed (method, N_f, seed) keys are skipped automatically.
Do not use --no-resume unless intentionally restarting from scratch.

Main output folder
------------------
main_v3_fairness_270/

Key final files:
- main_v3_fairness_270_combined.csv
- main_v3_fairness_270_summary.csv
- main_v3_fairness_270_flags.csv
- main_v3_fairness_270_stage_selection.csv
- main_v3_fairness_270_integrity.json
- main_v3_fairness_270_manifest.json
- main_v3_fairness_270.config.json

Backup raw files:
- main_v3_fairness_N50_30seeds.csv
- main_v3_fairness_N100_30seeds.csv
- main_v3_fairness_N200_30seeds.csv

Completion criterion
--------------------
Open main_v3_fairness_270_integrity.json after the run. It should report:
  expected_runs = 270
  unique_run_keys = 270
  duplicate_key_rows = 0
  missing_run_count = 0
  complete = true

A tiny pipeline test can be run with:
  python3 run_main_270_v3_fairness.py --dry-run

The dry-run is NOT part of the publication experiment.
