Online Resource 3 - Frozen PINN experiment source code
Journal: International Journal of Applied and Computational Mathematics
Article: Sample-Efficient Residual-Adaptive Collocation for Physics-Informed Neural Networks: A 270-Run Study of Shuttlecock Flipping Dynamics
Authors: Wahyu Hardyanto; Muhammad Farchani Rosyid; Siti Wahyuni; Listiyanto; Indri Hapsari
Corresponding author: Wahyu Hardyanto, hardy@mail.unnes.ac.id
ORCID: 0000-0002-2555-1437

Contents
- shuttlecock_pinn_diagnostic_v3_fairness.py: frozen implementation of the physical model, hard-IC PINN, fair MC-R/LHS-R/ALHS-R samplers, optimization, validation, and evaluation
- run_main_270_v3_fairness.py: frozen 270-run publication experiment preset
- README_main_270_v3_fairness.txt: execution instructions and frozen experiment design

The code reproduces the experiment protocol described in the article. The run-level output used for the paper is supplied separately as Online Resource 2.
